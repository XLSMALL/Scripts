//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B12_H_
#define B12_H_

#ifndef __SYNTHESIS__
bias12_t b12[4];
#else
bias12_t b12[4] = {0, 0, 0, 0};
#endif

#endif
