//Numpy array shape [1, 3]
//Min -0.124005883932
//Max 0.967912673950
//Number of zeros 0

#ifndef WR2_H_
#define WR2_H_

#ifndef __SYNTHESIS__
model_default_t wr2[3];
#else
model_default_t wr2[3] = {0.2185577154, -0.1240058839, 0.9679126740};
#endif

#endif
