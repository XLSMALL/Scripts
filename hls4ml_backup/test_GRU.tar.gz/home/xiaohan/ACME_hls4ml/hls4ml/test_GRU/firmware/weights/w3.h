//Numpy array shape [1, 1]
//Min 1.668697953224
//Max 1.668697953224
//Number of zeros 0

#ifndef W3_H_
#define W3_H_

#ifndef __SYNTHESIS__
model_default_t w3[1];
#else
model_default_t w3[1] = {1.6686979532};
#endif

#endif
