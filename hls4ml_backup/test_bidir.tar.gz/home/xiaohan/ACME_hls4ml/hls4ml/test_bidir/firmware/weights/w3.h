//Numpy array shape [2, 1]
//Min -0.375999450684
//Max 0.381758689880
//Number of zeros 0

#ifndef W3_H_
#define W3_H_

#ifndef __SYNTHESIS__
model_default_t w3[2];
#else
model_default_t w3[2] = {-0.3759994507, 0.3817586899};
#endif

#endif
