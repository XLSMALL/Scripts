//Numpy array shape [2, 3]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 6

#ifndef FORWARD_GRU_GRU_CELL_2_BIAS2_H_
#define FORWARD_GRU_GRU_CELL_2_BIAS2_H_

#ifndef __SYNTHESIS__
model_default_t forward_gru_gru_cell_2_bias2[6];
#else
model_default_t forward_gru_gru_cell_2_bias2[6] = {0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000};
#endif

#endif
