//Numpy array shape [2, 1]
//Min -1.159487128258
//Max 0.232226490974
//Number of zeros 0

#ifndef W4_H_
#define W4_H_

#ifndef __SYNTHESIS__
model_default_t w4[2];
#else
model_default_t w4[2] = {0.2322264910, -1.1594871283};
#endif

#endif
