//Numpy array shape [1, 3]
//Min -0.275488138199
//Max 0.946222305298
//Number of zeros 0

#ifndef FORWARD_GRU_GRU_CELL_2_RECURRENT_WEIGHT2_H_
#define FORWARD_GRU_GRU_CELL_2_RECURRENT_WEIGHT2_H_

#ifndef __SYNTHESIS__
model_default_t forward_gru_gru_cell_2_recurrent_weight2[3];
#else
model_default_t forward_gru_gru_cell_2_recurrent_weight2[3] = {0.9462223053, -0.1696156561, -0.2754881382};
#endif

#endif
