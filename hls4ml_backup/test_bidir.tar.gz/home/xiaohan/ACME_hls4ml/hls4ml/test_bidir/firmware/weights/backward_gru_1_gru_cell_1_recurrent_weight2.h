//Numpy array shape [1, 3]
//Min -0.080313444138
//Max 0.939732491970
//Number of zeros 0

#ifndef BACKWARD_GRU_1_GRU_CELL_1_RECURRENT_WEIGHT2_H_
#define BACKWARD_GRU_1_GRU_CELL_1_RECURRENT_WEIGHT2_H_

#ifndef __SYNTHESIS__
model_default_t backward_gru_1_gru_cell_1_recurrent_weight2[3];
#else
model_default_t backward_gru_1_gru_cell_1_recurrent_weight2[3] = {-0.0803134441, 0.3323438764, 0.9397324920};
#endif

#endif
