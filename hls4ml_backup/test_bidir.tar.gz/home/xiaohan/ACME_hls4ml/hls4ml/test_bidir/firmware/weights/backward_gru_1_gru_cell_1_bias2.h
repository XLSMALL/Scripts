//Numpy array shape [2, 3]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 6

#ifndef BACKWARD_GRU_1_GRU_CELL_1_BIAS2_H_
#define BACKWARD_GRU_1_GRU_CELL_1_BIAS2_H_

#ifndef __SYNTHESIS__
model_default_t backward_gru_1_gru_cell_1_bias2[6];
#else
model_default_t backward_gru_1_gru_cell_1_bias2[6] = {0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000};
#endif

#endif
