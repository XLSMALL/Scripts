//Numpy array shape [12]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 12

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[12];
#else
model_default_t b2[12] = {0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000, 0.0000000000};
#endif

#endif
