//Numpy array shape [4, 1]
//Min -0.536207914352
//Max 0.550670146942
//Number of zeros 0

#ifndef W5_H_
#define W5_H_

#ifndef __SYNTHESIS__
model_default_t w5[4];
#else
model_default_t w5[4] = {0.2296152115, -0.5362079144, 0.5506701469, 0.5102959871};
#endif

#endif
